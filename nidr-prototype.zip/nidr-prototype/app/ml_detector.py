"""
ml_detector.py
A placeholder anomaly detector. Here we featurize basic attributes and use
IsolationForest for anomaly scoring. In production you'd train on historic benign traffic.
"""
import numpy as np
from sklearn.ensemble import IsolationForest
from typing import Dict, List
import pickle
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "iforest.pkl")

def featurize(records: List[Dict]):
    # simple numeric features: length, sport, dport
    X = []
    for r in records:
        length = r.get("len", 0)
        sport = r.get("sport") or 0
        dport = r.get("dport") or 0
        try:
            sport_i = int(sport)
        except Exception:
            sport_i = 0
        try:
            dport_i = int(dport)
        except Exception:
            dport_i = 0
        X.append([length, sport_i, dport_i])
    return np.array(X)

class AnomalyDetector:
    def __init__(self, model=None):
        if model is not None:
            self.model = model
        else:
            self.model = IsolationForest(contamination=0.01, random_state=42)

    def fit(self, records: List[Dict]):
        X = featurize(records)
        if len(X) == 0:
            return
        self.model.fit(X)

    def score_records(self, records: List[Dict]):
        X = featurize(records)
        if len(X) == 0:
            return []
        # decision_function: higher = normal, lower = anomalous
        scores = self.model.decision_function(X)
        preds = self.model.predict(X)  # -1 is anomaly, 1 is normal
        return list(zip(scores.tolist(), preds.tolist()))
