"""
api.py - Flask API to list alerts and trigger simple response actions.
"""
from flask import Flask, jsonify, request
from .storage import init_db, SessionLocal, Alert
from sqlalchemy import desc

def create_app():
    app = Flask(__name__)
    init_db()

    @app.route("/alerts", methods=["GET"])
    def list_alerts():
        sess = SessionLocal()
        q = sess.query(Alert).order_by(desc(Alert.created_at)).limit(200).all()
        sess.close()
        results = [{
            "id": a.id, "name": a.name, "src": a.src, "dst": a.dst,
            "dport": a.dport, "score": a.score, "detail": a.detail,
            "created_at": a.created_at.isoformat()
        } for a in q]
        return jsonify(results)

    @app.route("/alerts/<int:alert_id>/respond", methods=["POST"])
    def respond(alert_id):
        # Example response: return a JSON describing an action you would take.
        # Real response code could call firewall API, orchestrator, etc.
        action = {"action": "quarantine", "status": "simulated", "alert_id": alert_id}
        return jsonify(action), 200

    return app
