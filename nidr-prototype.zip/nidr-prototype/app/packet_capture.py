"""
packet_capture.py
- Provides two ways to feed packets:
  1) live sniff (requires root and real interface) using scapy.sniff
  2) read-from-pcap for testing
- Produces simple normalized dict records consumed by detectors.
"""
from scapy.all import sniff, rdpcap
from typing import Callable, Generator, Dict

def packet_to_record(pkt) -> Dict:
    # Basic normalization: not exhaustive
    try:
        src = pkt[0].src
        dst = pkt[0].dst
    except Exception:
        src = getattr(pkt, 'src', None)
        dst = getattr(pkt, 'dst', None)
    record = {
        "src": src,
        "dst": dst,
        "len": len(pkt),
        "raw": bytes(pkt)[:256]  # truncated raw bytes
    }
    # If it has transport layer info
    if hasattr(pkt, 'sport'):
        record["sport"] = pkt.sport
    if hasattr(pkt, 'dport'):
        record["dport"] = pkt.dport
    return record

def read_pcap(path: str) -> Generator[Dict, None, None]:
    pcap = rdpcap(path)
    for pkt in pcap:
        yield packet_to_record(pkt)

def live_sniff(interface: str, callback: Callable, count: int = 0):
    """
    callback(record) will be called for each packet
    count=0 -> infinite until interrupted
    Requires privileges on many OSes.
    """
    def _pkt_handler(pkt):
        record = packet_to_record(pkt)
        callback(record)

    sniff(iface=interface, prn=_pkt_handler, count=count)
