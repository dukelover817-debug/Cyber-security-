"""
alerting.py
Creates alerts (stores them) and provides hooks for notifier integrations.
Notifier stubs (email, webhook) are placeholders.
"""
from .storage import save_alert

def create_alert(name, record, score=None, detail=""):
    src = record.get("src")
    dst = record.get("dst")
    dport = record.get("dport")
    alert = save_alert(name=name, src=src, dst=dst, dport=dport, score=score, detail=detail)
    # notifier hooks (email / webhook)
    # e.g., send_email(to, subject, body) -> implement in future
    print(f"[ALERT] {alert.id} {name} {src}->{dst}:{dport} score={score}")
    return alert
