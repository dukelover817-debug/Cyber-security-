"""
storage.py - simplistic SQLite storage using SQLAlchemy
"""
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime
import os

DB_PATH = os.environ.get("NIDR_DB", "sqlite:///nidr_alerts.db")

Base = declarative_base()
engine = create_engine(DB_PATH, echo=False, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128))
    src = Column(String(64))
    dst = Column(String(64))
    dport = Column(Integer)
    score = Column(Float, nullable=True)
    detail = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

def init_db():
    Base.metadata.create_all(bind=engine)

def save_alert(name, src, dst, dport=None, score=None, detail=""):
    sess = SessionLocal()
    a = Alert(name=name, src=src, dst=dst, dport=dport, score=score, detail=detail)
    sess.add(a)
    sess.commit()
    sess.refresh(a)
    sess.close()
    return a
