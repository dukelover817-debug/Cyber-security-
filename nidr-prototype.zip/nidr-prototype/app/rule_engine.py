"""
rule_engine.py
A tiny rule engine: rules are simple dicts with keys to match.
E.g. rule = {"name":"Block SSH brute", "dst":"10.0.0.5", "dport":22}
"""
from typing import Dict, List

class RuleEngine:
    def __init__(self, rules: List[Dict] = None):
        self.rules = rules or []

    def add_rule(self, rule: Dict):
        self.rules.append(rule)

    def match(self, record: Dict) -> List[Dict]:
        matches = []
        for r in self.rules:
            matched = True
            for k,v in r.items():
                if k == "name": continue
                if k not in record or record.get(k) != v:
                    matched = False
                    break
            if matched:
                matches.append(r)
        return matches

# Example convenience loader
def default_rules():
    return [
        {"name":"SSH-targeted","dport":22, "dst":"192.168.1.100"},
        {"name":"HTTP-target","dport":80, "dst":"192.168.1.200"},
    ]
