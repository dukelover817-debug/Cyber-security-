"""
main.py - Orchestrator
This example reads from a pcap (for safety/testing). It runs rule engine first, then anomaly detector in batches.
"""
import time
from .packet_capture import read_pcap
from .rule_engine import RuleEngine, default_rules
from .ml_detector import AnomalyDetector
from .alerting import create_alert
from .storage import init_db

BATCH_SIZE = 100

def run_from_pcap(pcap_path):
    init_db()
    engine = RuleEngine(default_rules())
    detector = AnomalyDetector()

    # Warm up ML model on first batch (synthetic fallback)
    batch = []
    for i, rec in enumerate(read_pcap(pcap_path), 1):
        # rule matching
        matches = engine.match(rec)
        if matches:
            for m in matches:
                create_alert(name=f"rule:{m.get('name')}", record=rec, detail=str(m))

        batch.append(rec)
        if len(batch) >= BATCH_SIZE:
            try:
                detector.fit(batch)
            except Exception as e:
                print("ML fit error:", e)
            scores = detector.score_records(batch)
            for r, (score, pred) in zip(batch, scores):
                if pred == -1:
                    create_alert(name="anomaly", record=r, score=float(score), detail="ml_anomaly")
            batch = []

    # process remainder
    if batch:
        try:
            detector.fit(batch)
            scores = detector.score_records(batch)
            for r, (score, pred) in zip(batch, scores):
                if pred == -1:
                    create_alert(name="anomaly", record=r, score=float(score), detail="ml_anomaly")
        except Exception as e:
            print("final ML error:", e)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Run NIDR prototype")
    parser.add_argument("--pcap", help="path to pcap file (recommended for demo)", required=True)
    args = parser.parse_args()
    run_from_pcap(args.pcap)
