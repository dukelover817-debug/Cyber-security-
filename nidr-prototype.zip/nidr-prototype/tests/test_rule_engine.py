from app.rule_engine import RuleEngine
def test_simple_match():
    r = {"name":"test","dport":22,"dst":"1.2.3.4"}
    e = RuleEngine([r])
    rec = {"dport":22, "dst":"1.2.3.4"}
    matches = e.match(rec)
    assert len(matches) == 1
