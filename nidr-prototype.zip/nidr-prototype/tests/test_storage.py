from app.storage import init_db, save_alert, SessionLocal
def test_save_and_query():
    init_db()
    a = save_alert("test", "1.1.1.1", "2.2.2.2", dport=1234, score=0.5, detail="unit test")
    sess = SessionLocal()
    got = sess.query(type(a)).filter_by(id=a.id).first()
    sess.close()
    assert got is not None
    assert got.src == "1.1.1.1"
